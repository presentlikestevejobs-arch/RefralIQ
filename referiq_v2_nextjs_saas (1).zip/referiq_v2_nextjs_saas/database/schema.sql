create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text default 'customer',
  created_at timestamptz default now()
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text,
  status text default 'inactive',
  price_id text,
  current_period_end timestamptz,
  created_at timestamptz default now()
);

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  website text,
  verified boolean default false,
  created_at timestamptz default now()
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  title text not null,
  description text,
  pay_min int,
  pay_max int,
  location text,
  work_arrangement text,
  commitment text,
  official_url text,
  referral_url text,
  is_active boolean default true,
  created_at timestamptz default now()
);

create table public.saved_jobs (
  user_id uuid references auth.users(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete cascade,
  created_at timestamptz default now(),
  primary key(user_id, job_id)
);

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete cascade,
  clicked_url text,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.saved_jobs enable row level security;
alter table public.applications enable row level security;

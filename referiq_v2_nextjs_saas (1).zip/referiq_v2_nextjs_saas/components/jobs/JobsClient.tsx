"use client";

import { useMemo, useState } from "react";
import { jobs, type Job } from "@/lib/data/jobs";
import { Button } from "@/components/ui/Button";

type Props = {
  isPaid?: boolean;
};

export function JobsClient({ isPaid = false }: Props) {
  const [query, setQuery] = useState("");
  const [pay, setPay] = useState("");
  const [location, setLocation] = useState("");
  const [type, setType] = useState("");
  const [work, setWork] = useState("");
  const [sort, setSort] = useState("newest");
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);

  const filtered = useMemo(() => {
    let result = jobs.filter((job) => {
      const search = `${job.title} ${job.location} ${job.work} ${job.type} ${job.tags.join(" ")}`.toLowerCase();
      if (query && !search.includes(query.toLowerCase())) return false;
      if (pay && job.minPay < Number(pay)) return false;
      if (location && !job.location.includes(location)) return false;
      if (type && job.type !== type) return false;
      if (work && job.work !== work) return false;
      return true;
    });

    if (sort === "payHigh") result = [...result].sort((a, b) => b.minPay - a.minPay);
    if (sort === "payLow") result = [...result].sort((a, b) => a.minPay - b.minPay);
    return result;
  }, [query, pay, location, type, work, sort]);

  return (
    <div className="mx-auto max-w-7xl px-6 py-14">
      <div className="mb-8 flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-muted">295 Open Roles</div>
          <h1 className="text-5xl font-black tracking-[-0.06em]">All open AI training roles.</h1>
          <p className="mt-4 max-w-2xl leading-7 text-muted">
            Search by role, pay rate, location and flexibility. Company names and apply links unlock after payment.
          </p>
        </div>
        {!isPaid && <Button href="/login" variant="primary">Pay $9 to Unlock</Button>}
      </div>

      <div className="sticky top-24 z-20 mb-6 rounded-[2rem] border border-line bg-white/90 p-4 shadow-premium backdrop-blur-2xl">
        <div className="mb-3 grid grid-cols-[1fr_58px] gap-3">
          <input
            className="h-14 rounded-2xl border border-line px-5 outline-none focus:border-ink"
            placeholder="Search AI roles, skills, categories..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button className="rounded-2xl bg-ink text-xl text-white">⌕</button>
        </div>
        <div className="grid gap-3 md:grid-cols-4">
          <select className="h-12 rounded-2xl border border-line px-4 font-bold" value={pay} onChange={(e) => setPay(e.target.value)}>
            <option value="">Pay Rate</option><option value="20">$20+/hr</option><option value="40">$40+/hr</option><option value="80">$80+/hr</option>
          </select>
          <select className="h-12 rounded-2xl border border-line px-4 font-bold" value={location} onChange={(e) => setLocation(e.target.value)}>
            <option value="">Location</option><option value="Worldwide">Worldwide</option><option value="US">US</option><option value="Latin America">Latin America</option>
          </select>
          <select className="h-12 rounded-2xl border border-line px-4 font-bold" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">Commitment</option><option>Full Time</option><option>Part Time</option><option>Contract</option><option>Freelance</option>
          </select>
          <select className="h-12 rounded-2xl border border-line px-4 font-bold" value={work} onChange={(e) => setWork(e.target.value)}>
            <option value="">Work Arrangement</option><option>Remote</option><option>Hybrid</option><option>On-site</option>
          </select>
        </div>
      </div>

      <div className="mb-5 flex items-center justify-between text-sm text-muted">
        <span>{filtered.length} roles found</span>
        <select className="rounded-full border border-line bg-white px-4 py-2" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="newest">Newest</option>
          <option value="payHigh">Highest Pay</option>
          <option value="payLow">Lowest Pay</option>
        </select>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {filtered.map((job) => (
          <article key={job.id} className="grid grid-cols-[1fr_48px] items-center gap-4 rounded-[1.75rem] border border-line bg-white p-5 shadow-soft transition hover:-translate-y-1 hover:shadow-premium">
            <div>
              <div className="mb-3 flex items-center gap-3 text-xs font-black uppercase text-muted">
                <div className="grid h-11 w-11 place-items-center rounded-2xl bg-ink text-white">AI</div>
                <span>{isPaid ? job.company : "Company hidden"}</span>
                <span>{job.date}</span>
              </div>
              <h3 className="text-xl font-black tracking-[-0.035em]">{job.title}</h3>
              <p className="mt-3 flex flex-wrap gap-3 text-sm font-bold text-muted">
                <span className="text-ink">{job.pay}</span><span>{job.work} · {job.location}</span><span>{job.type}</span>
              </p>
              <p className="mt-3 text-xs text-muted">
                {isPaid ? "Official and referral links available." : "Company name, official apply link and referral link unlock after payment."}
              </p>
            </div>
            <button onClick={() => setSelectedJob(job)} className="h-12 w-12 rounded-2xl border border-line text-2xl">→</button>
          </article>
        ))}
      </div>

      {selectedJob && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-5">
          <div className="w-full max-w-xl rounded-[2rem] bg-white p-8 shadow-premium">
            <div className="flex justify-between gap-4">
              <div>
                <div className="text-xs font-black uppercase tracking-[0.18em] text-muted">Job Details</div>
                <h2 className="mt-2 text-3xl font-black tracking-[-0.05em]">{selectedJob.title}</h2>
              </div>
              <button onClick={() => setSelectedJob(null)} className="h-11 w-11 rounded-full border border-line text-2xl">×</button>
            </div>
            <div className="my-5 overflow-hidden rounded-3xl border border-line">
              <Row label="Company" value={isPaid ? selectedJob.company : "Hidden Partner"} locked={!isPaid} />
              <Row label="Official Apply Link" value={isPaid ? selectedJob.applyUrl : "https://apply..."} locked={!isPaid} />
              <Row label="Referral Link" value={isPaid ? selectedJob.referralUrl : "https://ref..."} locked={!isPaid} />
              <Row label="Requirements" value={isPaid ? "Visible" : "Members only"} locked={!isPaid} />
            </div>
            {isPaid ? (
              <Button className="w-full" variant="primary">Open Apply Link</Button>
            ) : (
              <Button className="w-full" href="/login" variant="primary">Pay $9 to Unlock</Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, locked }: { label: string; value: string; locked?: boolean }) {
  return (
    <div className="flex justify-between gap-4 border-b border-line px-5 py-4 last:border-b-0">
      <span className="text-muted">{label}</span>
      <strong className={locked ? "lock-blur" : ""}>{value}</strong>
    </div>
  );
}

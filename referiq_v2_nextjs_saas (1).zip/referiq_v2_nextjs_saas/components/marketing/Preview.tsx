export function Preview() {
  const roles = [
    ["AI Coding Trainer", "$50–150/hr · Remote · Verified"],
    ["AI Medical Reviewer", "$80–150/hr · Remote · Members only"],
    ["Prompt Quality Evaluator", "$35–90/hr · Flexible · Updated today"]
  ];

  return (
    <section className="mx-auto max-w-6xl px-6">
      <div className="overflow-hidden rounded-[2rem] border border-line bg-white shadow-premium">
        <div className="flex h-14 items-center justify-between border-b border-line px-6">
          <div className="flex gap-2">
            <span className="h-3 w-3 rounded-full bg-line" />
            <span className="h-3 w-3 rounded-full bg-line" />
            <span className="h-3 w-3 rounded-full bg-line" />
          </div>
          <span className="text-xs font-bold text-muted">ReferIQ Job Intelligence</span>
        </div>
        <div className="grid md:grid-cols-[320px_1fr]">
          <aside className="hidden border-r border-line bg-soft p-6 md:block">
            <p className="mb-4 text-xs font-black uppercase tracking-[0.16em] text-muted">Filters</p>
            {["Pay Rate · $40+/hr", "Location · Remote", "Skill · Coding", "Commitment · Contract"].map(item => (
              <div key={item} className="mb-3 rounded-2xl border border-line bg-white px-4 py-3 text-sm text-muted">{item}</div>
            ))}
          </aside>
          <main className="p-5">
            <div className="mb-4 flex h-14 items-center justify-between rounded-2xl border border-line px-5 text-muted">
              Search AI roles <strong>⌕</strong>
            </div>
            <div className="grid gap-3">
              {roles.map(([title, desc]) => (
                <div key={title} className="flex items-center justify-between rounded-3xl border border-line p-5">
                  <div>
                    <h3 className="text-xl font-black tracking-[-0.03em]">{title}</h3>
                    <p className="mt-1 text-sm text-muted">{desc}</p>
                  </div>
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border border-line">→</div>
                </div>
              ))}
            </div>
          </main>
        </div>
      </div>
    </section>
  );
}

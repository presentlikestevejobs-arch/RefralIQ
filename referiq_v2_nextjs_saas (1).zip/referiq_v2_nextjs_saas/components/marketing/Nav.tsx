import { Button } from "@/components/ui/Button";

export function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-line bg-white/85 backdrop-blur-2xl">
      <div className="mx-auto flex h-22 max-w-7xl items-center justify-between px-6">
        <div className="flex items-center gap-3 text-3xl font-black tracking-[-0.06em]">
          <div className="grid h-10 w-10 place-items-center rounded-2xl bg-ink text-lg text-white">R</div>
          ReferIQ
        </div>
        <nav className="hidden gap-9 text-sm font-bold md:flex">
          <a href="/">Home</a>
          <a href="/jobs">AI Roles</a>
        </nav>
        <Button href="/jobs" variant="primary">Start Exploring</Button>
      </div>
    </header>
  );
}

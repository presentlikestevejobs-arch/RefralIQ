import { Button } from "@/components/ui/Button";

export function Hero() {
  return (
    <section className="mx-auto max-w-7xl px-6 pb-10 pt-24 text-center">
      <div className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-4 py-2 text-sm text-muted shadow-soft">
        <span className="h-2 w-2 rounded-full bg-ink" />
        Remote AI Work · Curated Daily
      </div>
      <h1 className="mx-auto mt-7 max-w-5xl text-[clamp(3rem,8vw,5.5rem)] font-black leading-[0.93] tracking-[-0.075em]">
        Get Paid $30–150/hour Training AI
      </h1>
      <p className="mx-auto mt-7 max-w-3xl text-lg leading-8 text-muted md:text-xl">
        Discover verified AI training opportunities by skill, pay rate and flexibility. Company names and apply links unlock after payment.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button href="/jobs" variant="primary">Start Exploring Jobs</Button>
        <Button href="#roles">View Popular Roles</Button>
      </div>
    </section>
  );
}

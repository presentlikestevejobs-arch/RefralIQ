import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0A0A0A",
        muted: "#6B7280",
        line: "#E5E7EB",
        soft: "#F7F8FA"
      },
      borderRadius: {
        xl2: "1.25rem",
        xl3: "1.75rem"
      },
      boxShadow: {
        premium: "0 30px 80px rgba(0,0,0,.08)",
        soft: "0 14px 38px rgba(0,0,0,.06)"
      }
    }
  },
  plugins: []
};

export default config;

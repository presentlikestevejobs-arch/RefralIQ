export type Job = {
  id: string;
  company: string;
  title: string;
  pay: string;
  minPay: number;
  location: string;
  work: "Remote" | "Hybrid" | "On-site";
  type: "Full Time" | "Part Time" | "Contract" | "Freelance";
  tags: string[];
  date: string;
  applyUrl: string;
  referralUrl: string;
};

export const jobs: Job[] = [
  {
    id: "1",
    company: "Data Quality Labs",
    title: "General task — text quality reviewer",
    pay: "$22–32/hr",
    minPay: 22,
    location: "US/CA/UK",
    work: "Remote",
    type: "Freelance",
    tags: ["Annotation", "Content", "Training", "Remote"],
    date: "Apr 25",
    applyUrl: "https://official.apply/text-reviewer",
    referralUrl: "https://ref.apply/text-reviewer"
  },
  {
    id: "2",
    company: "Code Intelligence Partner",
    title: "Senior software engineer — RLHF for code models",
    pay: "$55–80/hr",
    minPay: 55,
    location: "Worldwide",
    work: "Remote",
    type: "Contract",
    tags: ["Coding", "RLHF", "Training", "Remote"],
    date: "Apr 23",
    applyUrl: "https://official.apply/rlhf-code",
    referralUrl: "https://ref.apply/rlhf-code"
  },
  {
    id: "3",
    company: "Clinical AI Review",
    title: "Medical reviewer — clinical reasoning",
    pay: "$80–150/hr",
    minPay: 80,
    location: "US/CA/UK/AU",
    work: "Remote",
    type: "Contract",
    tags: ["Medical", "Healthcare", "Training", "Remote"],
    date: "Apr 21",
    applyUrl: "https://official.apply/medical-reviewer",
    referralUrl: "https://ref.apply/medical-reviewer"
  },
  {
    id: "4",
    company: "Math Reasoning Lab",
    title: "Math PhD — verification of step-by-step reasoning",
    pay: "$50–75/hr",
    minPay: 50,
    location: "Worldwide",
    work: "Remote",
    type: "Part Time",
    tags: ["Math", "Reasoning", "Training", "Remote"],
    date: "Apr 20",
    applyUrl: "https://official.apply/math-phd",
    referralUrl: "https://ref.apply/math-phd"
  }
];

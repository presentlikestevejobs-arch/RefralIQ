// Replace with Supabase subscription lookup in production.
export async function getSubscriptionStatus() {
  return false;
}

import { Nav } from "@/components/marketing/Nav";
import { Hero } from "@/components/marketing/Hero";
import { Preview } from "@/components/marketing/Preview";

const roles = [
  ["AI Prompt Engineer", "$45–120/hr", "Create, test and improve prompts for AI models."],
  ["AI Coding Trainer", "$50–150/hr", "Train models on programming, debugging and reasoning."],
  ["AI Voice Trainer", "$30–60/hr", "Evaluate speech, pronunciation and audio quality."],
  ["Medical AI Reviewer", "$80–150/hr", "Review clinical reasoning and healthcare responses."],
  ["Math Evaluator", "$35–90/hr", "Check step-by-step reasoning and answer quality."],
  ["Data Annotator", "$20–45/hr", "Label text, images and AI-generated responses."]
];

export default function HomePage() {
  return (
    <>
      <Nav />
      <Hero />
      <Preview />

      <section className="mx-auto grid max-w-6xl gap-4 px-6 py-14 md:grid-cols-3">
        <Metric value="$30–150/hr" label="Possible hourly range" />
        <Metric value="18,542+" label="Verified opportunities" />
        <Metric value="Remote-first" label="Work from anywhere" />
      </section>

      <section id="roles" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mb-9 max-w-3xl">
          <div className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-muted">Popular Categories</div>
          <h2 className="text-5xl font-black leading-tight tracking-[-0.06em]">Built for the new AI workforce.</h2>
          <p className="mt-4 text-lg leading-8 text-muted">Role-first discovery without exposing company names on the public front.</p>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {roles.map(([title, pay, desc]) => (
            <div key={title} className="rounded-[1.75rem] border border-line bg-white p-7 shadow-soft transition hover:-translate-y-1 hover:shadow-premium">
              <h3 className="text-2xl font-black tracking-[-0.04em]">{title}</h3>
              <div className="mt-3 text-xl font-black">{pay}</div>
              <p className="mt-3 leading-7 text-muted">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

function Metric({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-[1.75rem] border border-line bg-white p-7 shadow-soft">
      <b className="text-3xl font-black tracking-[-0.04em]">{value}</b>
      <p className="mt-2 text-muted">{label}</p>
    </div>
  );
}

export default function AdminDashboardPage() {
  return (
    <div className="grid min-h-screen md:grid-cols-[265px_1fr]">
      <aside className="border-r border-line bg-soft p-5">
        <div className="mb-8 text-2xl font-black tracking-[-0.05em]">ReferIQ Admin</div>
        {["Overview", "Users", "Jobs", "Payments", "Analytics"].map((item) => (
          <div key={item} className="mb-2 rounded-2xl px-4 py-3 text-sm font-bold text-muted hover:bg-ink hover:text-white">{item}</div>
        ))}
      </aside>
      <main className="p-6 md:p-10">
        <h1 className="text-4xl font-black tracking-[-0.06em]">Admin Overview</h1>
        <div className="mt-6 grid gap-4 md:grid-cols-4">
          <Card value="2,845" label="Users" />
          <Card value="$19,179" label="MRR" />
          <Card value="18,542" label="Jobs" />
          <Card value="1,284" label="Companies" />
        </div>
      </main>
    </div>
  );
}

function Card({ value, label }: { value: string; label: string }) {
  return <div className="rounded-[1.5rem] border border-line bg-white p-5 shadow-soft"><h3 className="text-3xl font-black">{value}</h3><p className="text-muted">{label}</p></div>;
}

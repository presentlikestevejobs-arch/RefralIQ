import { redirect } from "next/navigation";
import { getSubscriptionStatus } from "@/lib/subscription";
import { jobs } from "@/lib/data/jobs";

export default async function DashboardPage() {
  const isPaid = await getSubscriptionStatus();
  if (!isPaid) redirect("/login");

  return (
    <div className="grid min-h-screen md:grid-cols-[265px_1fr]">
      <aside className="border-r border-line bg-soft p-5">
        <div className="mb-8 text-2xl font-black tracking-[-0.05em]">ReferIQ</div>
        {["Dashboard", "AI Jobs", "Billing", "Sign Out"].map((item) => (
          <div key={item} className="mb-2 rounded-2xl px-4 py-3 text-sm font-bold text-muted hover:bg-ink hover:text-white">{item}</div>
        ))}
      </aside>
      <main className="p-6 md:p-10">
        <h1 className="text-4xl font-black tracking-[-0.06em]">Customer Dashboard</h1>
        <div className="mt-6 grid gap-4 md:grid-cols-4">
          <Card value="18,542" label="Total Jobs" />
          <Card value="143" label="New Today" />
          <Card value="Active" label="Membership" />
          <Card value="12" label="Saved Jobs" />
        </div>
        <div className="mt-8 overflow-x-auto rounded-3xl border border-line">
          <table className="w-full min-w-[760px] text-left">
            <thead className="bg-soft text-sm text-muted">
              <tr><th className="p-4">Company</th><th>Role</th><th>Pay</th><th>Location</th><th>Apply</th></tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr key={job.id} className="border-t border-line">
                  <td className="p-4 font-bold">{job.company}</td>
                  <td>{job.title}</td>
                  <td>{job.pay}</td>
                  <td>{job.location}</td>
                  <td><button className="rounded-full bg-ink px-4 py-2 text-sm font-bold text-white">Apply</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}

function Card({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-[1.5rem] border border-line bg-white p-5 shadow-soft">
      <h3 className="text-3xl font-black tracking-[-0.04em]">{value}</h3>
      <p className="mt-1 text-muted">{label}</p>
    </div>
  );
}

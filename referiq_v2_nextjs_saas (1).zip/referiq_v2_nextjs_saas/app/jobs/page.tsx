import { Nav } from "@/components/marketing/Nav";
import { JobsClient } from "@/components/jobs/JobsClient";
import { getSubscriptionStatus } from "@/lib/subscription";

export default async function JobsPage() {
  const isPaid = await getSubscriptionStatus();

  return (
    <>
      <Nav />
      <JobsClient isPaid={isPaid} />
    </>
  );
}

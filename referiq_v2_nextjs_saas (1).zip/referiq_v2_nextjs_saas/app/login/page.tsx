import { Button } from "@/components/ui/Button";

export default function LoginPage() {
  return (
    <main className="grid min-h-screen place-items-center bg-white px-6">
      <div className="w-full max-w-md rounded-[2rem] border border-line bg-white p-8 shadow-premium">
        <div className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-muted">Membership Required</div>
        <h1 className="text-4xl font-black tracking-[-0.06em]">Unlock ReferIQ</h1>
        <p className="mt-3 leading-7 text-muted">
          Payment ke baad company names, official apply links, referral links aur dashboard visible honge.
        </p>
        <div className="my-6 rounded-3xl border border-line bg-soft p-5">
          <h2 className="text-3xl font-black">$9/month</h2>
          <p className="mt-2 text-sm text-muted">Unlimited AI roles, company names, official apply links and referral links.</p>
        </div>
        <form action="/api/stripe/checkout" method="POST">
          <Button className="w-full" variant="primary">Pay $9 & Unlock Dashboard</Button>
        </form>
      </div>
    </main>
  );
}

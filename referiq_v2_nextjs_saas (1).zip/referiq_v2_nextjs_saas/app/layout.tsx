import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ReferIQ — Premium AI Job Intelligence",
  description: "Get paid $30–150/hour training AI. Discover verified AI opportunities in one membership."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

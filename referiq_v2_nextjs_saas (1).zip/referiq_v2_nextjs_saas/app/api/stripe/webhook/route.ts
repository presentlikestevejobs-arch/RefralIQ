import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe/server";

export async function POST(req: Request) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");

  try {
    const event = stripe.webhooks.constructEvent(
      body,
      signature || "",
      process.env.STRIPE_WEBHOOK_SECRET || "whsec_demo"
    );

    // TODO: update Supabase subscription table here.
    // checkout.session.completed -> active
    // customer.subscription.deleted -> cancelled

    return NextResponse.json({ received: true, type: event.type });
  } catch (error) {
    return NextResponse.json({ error: "Webhook error" }, { status: 400 });
  }
}

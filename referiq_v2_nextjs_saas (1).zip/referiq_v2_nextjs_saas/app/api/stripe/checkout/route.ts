import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe/server";

export async function POST() {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    line_items: [
      {
        price: process.env.STRIPE_PRICE_ID || "price_demo",
        quantity: 1
      }
    ],
    success_url: `${appUrl}/dashboard?checkout=success`,
    cancel_url: `${appUrl}/login?checkout=cancelled`
  });

  return NextResponse.redirect(session.url || `${appUrl}/login`, 303);
}

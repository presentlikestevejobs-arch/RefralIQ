# ReferIQ v2 — Production SaaS Starter

Premium Next.js SaaS architecture for ReferIQ.

## Stack
- Next.js App Router
- TypeScript
- Tailwind CSS
- Framer Motion
- Shadcn-style components
- Supabase Auth + PostgreSQL
- Stripe Checkout + Webhooks
- Responsive SaaS design inspired by Micro1 + AIJobs + Linear + Stripe

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Demo flow
- Public landing + jobs page
- Company names/apply/referral links are locked
- Login/signup page
- Stripe checkout route
- Dashboard unlocks after subscription status is active
- Customer dashboard
- Company dashboard
- Admin dashboard

## Important
This is a production-ready scaffold. Add your real Supabase keys and Stripe keys in `.env.local`.
